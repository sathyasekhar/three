package com.example.customer.breaker;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.customer.feign.FriendFeign;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Component
public class CustomerCircuit {
	
	private static final String FRIEND_URL = "http://FRIENDMS/Friend/{phoneNumber}";
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	FriendFeign  friendFeign;
	
	@HystrixCommand(fallbackMethod = "getFriendsFallback")	
	public List<Long>  getFriends(Long phoneNumber) {
		//List<Long> friendsContactNumbers = restTemplate.getForObject(FRIEND_URL, List.class, phoneNumber);
		List<Long> friendsContactNumbers = friendFeign.getFriends(phoneNumber);
		return friendsContactNumbers;
	}
	
	public List<Long>  getFriendsFallback(Long phoneNumber){
		return  new  ArrayList<Long>();
	}

}
