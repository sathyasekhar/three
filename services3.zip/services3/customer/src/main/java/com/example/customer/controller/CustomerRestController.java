package com.example.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.customer.breaker.CustomerCircuit;
import com.example.customer.dto.CustomerDto;
import com.example.customer.dto.LoginDTO;
import com.example.customer.dto.PlanDTO;
import com.example.customer.entity.Customer;
import com.example.customer.feign.PlanFeign;
import com.example.customer.service.ICustomerService;

@RestController

public class CustomerRestController {
	@Autowired
	CustomerCircuit  circuit;
	
	
	@Autowired
	ICustomerService  service;

	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	PlanFeign  planFeign;
	
	
	private static final String PLAN_URL = "http://PLANMS/Plan/{planId}";
	private static final String FRIEND_URL = "http://FRIENDMS/Friend/{phoneNumber}";
	
	
	@PostMapping("/register")
	public boolean  addCustomer(@RequestBody Customer customer) {
		return service.registerCustomer(customer);
	}
	
	@PostMapping("/login")
	public  boolean  loginCustomer(@RequestBody  LoginDTO loginDto) {
		return  service.loginCustomer(loginDto);
	}
	
	@GetMapping("/viewProfile/{phoneNumber}")
	public  CustomerDto  showProfile(@PathVariable Long phoneNumber) {
		CustomerDto  customerDto=service.readCustomer(phoneNumber);
		
		
		//calling plan microservice
		PlanDTO planDto = planFeign.getPlanData(customerDto.getPlanId());
		customerDto.setCurrentPlan(planDto);
		
		//calling friend microservice
		//List<Long> friendsContactNumbers = restTemplate.getForObject(FRIEND_URL, List.class, phoneNumber);
		List<Long> friendsContactNumbers = circuit.getFriends(phoneNumber);
		customerDto.setFriendsContactNumbers(friendsContactNumbers);
	
		return customerDto;
		
	}
	
}
