package com.example.customer.service;

import com.example.customer.dto.CustomerDto;
import com.example.customer.dto.LoginDTO;
import com.example.customer.entity.Customer;

public interface ICustomerService {
	
	boolean  registerCustomer(Customer customer);
	
	boolean  loginCustomer(LoginDTO  loginDto);
	
	CustomerDto  readCustomer(Long phoneNumber);
}
