package com.example.customer.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.customer.dto.PlanDTO;

@Component
@FeignClient("PLANMS")
public interface PlanFeign {
	
	@RequestMapping("/Plan/{planId}")
	PlanDTO getPlanData(@PathVariable String planId); 
	
}
